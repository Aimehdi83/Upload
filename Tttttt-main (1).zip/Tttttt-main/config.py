# config.py

BOT_TOKEN = "7413532622:AAE2304MGwjtHqPUEFRRUXmlyq2bQAQqQFg"
WEBHOOK_URL = "https://tttttt-v1kw.onrender.com/webhook"
ADMIN_IDS = [6387942633, 7189616405, 5459406429]  # شناسه عددی ادمین‌ها
CHANNEL_TAG = "🔥@hottof | تُفِ داغ " 
PING_INTERVAL = 240  # فاصله زمانی بین پینگ‌ها به ثانیه
